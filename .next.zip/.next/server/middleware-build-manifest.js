globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/61ca1dcbe3a111c8.js",
    "static/chunks/f091501564eb2ea3.js",
    "static/chunks/0333325c42d9d441.js",
    "static/chunks/773abe17875a49cc.js",
    "static/chunks/turbopack-2b1438aef4c63e68.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];