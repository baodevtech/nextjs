module.exports=[64468,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_pricing_page_actions_61c195a2.js.map