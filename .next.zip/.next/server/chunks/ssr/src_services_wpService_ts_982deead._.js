module.exports=[11544,a=>{"use strict";let b=process.env.NEXT_PUBLIC_WORDPRESS_API_URL||"https://portal.khopanel.com/graphql";async function c(a,{variables:d}={},e,f=[]){try{let c=await fetch(b,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({query:a,variables:d}),cache:"force-cache",next:{tags:f}}),e=await c.json();if(e.errors)return null;return e.data}catch(a){return null}}let d=`
  fragment ProductFields on Product {
    id
    databaseId
    slug
    name
    sku
    shortDescription
    description
    ... on SimpleProduct {
      price(format: RAW)
      regularPrice(format: RAW)
      stockStatus
    }
    ... on VariableProduct {
      price(format: RAW)
      regularPrice(format: RAW)
      stockStatus
    }
    image {
      sourceUrl
      altText
    }
    galleryImages {
      nodes {
        sourceUrl
        altText
      }
    }
    productCategories {
      nodes {
        slug
        name
      }
    }
    productBrands {
      nodes {
        name
        slug
      }
    }
    productSpecifications {
      length
      width
      thickness
      area
      origin
      surface
      warranty
    }
  }
`,e=a=>{if(!a)return{};let b=a.price?parseFloat(a.price.replace(/[^0-9.]/g,"")):0,c=a.productBrands?.nodes&&a.productBrands.nodes.length>0?a.productBrands.nodes[0].name:"Đại Nam Wall";return{id:a.id,databaseId:a.databaseId,slug:a.slug,name:a.name,brand:c,origin:a.productSpecifications?.origin||"",surface:a.productSpecifications?.surface||"",warranty:a.productSpecifications?.warranty||"",description:a.description||"",shortDescription:a.shortDescription||"",image:{sourceUrl:a.image?.sourceUrl||"https://via.placeholder.com/600x600?text=No+Image",altText:a.image?.altText||a.name},galleryImages:a.galleryImages?.nodes?.map(b=>({sourceUrl:b.sourceUrl,altText:b.altText||a.name}))||[],price:{amount:b,formatted:new Intl.NumberFormat("vi-VN",{style:"currency",currency:"VND"}).format(b)},stockStatus:"IN_STOCK"===a.stockStatus?"IN_STOCK":"OUT_OF_STOCK",sku:a.sku||"",categories:a.productCategories?.nodes?.map(a=>a.slug)||[],dimensions:{length:Number(a.productSpecifications?.length)||0,width:Number(a.productSpecifications?.width)||0,thickness:Number(a.productSpecifications?.thickness)||0,area:Number(a.productSpecifications?.area)||0}}},f=async()=>{let a=await c(`
    ${d}
    query GetProducts {
      products(first: 20, where: { orderby: { field: DATE, order: DESC } }) {
        nodes {
          ...ProductFields
        }
      }
    }
  `,{},void 0,["products"]);return a&&a.products?a.products.nodes.map(e):[]},g=async()=>{let a=await c(`
    query GetShopSettings {
      options {
        shopSettings {
          shopDescription
          benefitWarranty {
            heading
            subHeading
            icon { node { sourceUrl } }
          }
          benefitShipping {
            heading
            subHeading
            icon { node { sourceUrl } }
          }
          benefitVariety {
            heading
            subHeading
            icon { node { sourceUrl } }
          }
        }
      }
    }
  `,{},void 0,["shop_settings","options"]),b=a?.options?.shopSettings;return b?{description:b.shopDescription||"",benefits:{warranty:{heading:b.benefitWarranty?.heading||"",subHeading:b.benefitWarranty?.subHeading||"",icon:b.benefitWarranty?.icon?.node?.sourceUrl||""},shipping:{heading:b.benefitShipping?.heading||"",subHeading:b.benefitShipping?.subHeading||"",icon:b.benefitShipping?.icon?.node?.sourceUrl||""},variety:{heading:b.benefitVariety?.heading||"",subHeading:b.benefitVariety?.subHeading||"",icon:b.benefitVariety?.icon?.node?.sourceUrl||""}}}:null},h=async a=>{let b=await c(`
    ${d}
    query GetProductBySlug($slug: ID!) {
      product(id: $slug, idType: SLUG) {
        ...ProductFields
      }
    }
  `,{variables:{slug:a}},void 0,["products",`product-${a}`]);if(b?.product)return e(b.product)},i=a=>({id:a.id,name:a.name,slug:a.slug,count:a.count||0,image:a.image?.sourceUrl||"https://via.placeholder.com/400x400?text=Category",description:a.description,headerImage:a.categoryExtras?.headerImage?.node?.sourceUrl||a.image?.sourceUrl||"",bottomContent:a.categoryExtras?.bottomContent||"",trendHeader:a.categoryExtras?.trendHeader||"",trendContent:a.categoryExtras?.trendContent||"",warrantyMonths:a.categoryExtras?.warrantyMonths||0}),j=async()=>{let a=await c(`
    query GetCategories {
      productCategories(first: 20, where: { hideEmpty: true, parent: 0 }) {
        nodes {
          id
          name
          slug
          count
          description
          image {
            sourceUrl
          }
          categoryExtras {
            headerImage { node { sourceUrl } }
            bottomContent
            trendHeader
            trendContent
            warrantyMonths
          }
        }
      }
    }
  `,{},void 0,["categories"]);return a&&a.productCategories?a.productCategories.nodes.map(i):[]},k=a=>Array.isArray(a)?a.map(a=>e(a)):[],l=a=>a?a.sourceUrl?a.sourceUrl:a.node?.sourceUrl?a.node.sourceUrl:a.edges?.[0]?.node?.sourceUrl?a.edges[0].node.sourceUrl:"":"",m=a=>a?a.map(a=>{let b=new Date(a.date),c=new Intl.DateTimeFormat("vi-VN").format(b),d=a.content?a.content.replace(/<[^>]+>/g,""):"",e=a.excerpt?a.excerpt.replace(/<[^>]+>/g,""):"",f=Math.ceil(d.split(/\s+/).length/200),g=f>0?`${f} ph\xfat đọc`:"1 phút đọc";return{id:a.id,title:a.title||"",slug:a.slug||"",excerpt:e,content:a.content||"",date:c,readTime:g,image:a.featuredImage?.node?.sourceUrl||"https://via.placeholder.com/800x600?text=No+Image",category:a.categories?.nodes?.[0]?.name||"Tin tức",author:{name:a.author?.node?.name||"Admin",avatar:a.author?.node?.avatar?.url||"",role:"Tác giả"},tags:a.tags?.nodes?.map(a=>a.name)||[]}}):[],n=async a=>{let b=await c(`
    query GetPostBySlug($id: ID!) {
      post(id: $id, idType: SLUG) {
        id
        title
        slug
        date
        excerpt
        content
        featuredImage { node { sourceUrl } }
        categories { nodes { name, slug } }
        tags { nodes { name, slug } }
        author { node { name, avatar { url } } }
      }
    }
  `,{variables:{id:a}},void 0,["posts",`post-${a}`]);return b?.post?m([b.post])[0]:null},o=async(a,b,d=2)=>{let e=await c(`
    query GetRelatedPosts($categoryName: String, $notIn: [ID]) {
      posts(first: ${d}, where: { categoryName: $categoryName, notIn: $notIn, orderby: { field: DATE, order: DESC } }) {
        nodes {
          id
          title
          slug
          date
          excerpt
          content
          featuredImage { node { sourceUrl } }
          categories { nodes { name, slug } }
          tags { nodes { name, slug } }
          author { node { name, avatar { url } } }
        }
      }
    }
  `,{variables:{categoryName:a,notIn:[b]}},void 0,["posts"]);return m(e?.posts?.nodes||[])},p=async(a=5,b="",d="All",e="",f="")=>{let g="orderby: { field: DATE, order: DESC }";d&&"All"!==d&&(g+=`, categoryName: "${d}"`),e&&(g+=`, search: "${e}"`),f&&(g+=`, tag: "${f}"`);let h=`
    query GetPaginatedPosts($first: Int!, $after: String) {
      posts(first: $first, after: $after, where: { ${g} }) {
        pageInfo {
          hasNextPage
          endCursor
        }
        nodes {
          id, title, slug, date, excerpt, content
          featuredImage { node { sourceUrl } }
          categories { nodes { name, slug } }
          tags { nodes { name, slug } }
          author { node { name, avatar { url } } }
        }
      }
    }
  `,i=await c(h,{variables:{first:a,after:b}},void 0,["posts"]);return{posts:m(i?.posts?.nodes||[]),pageInfo:i?.posts?.pageInfo||{hasNextPage:!1,endCursor:""}}},q=async()=>{let a=await c(`
    query GetBlogCategories {
      categories(first: 20, where: { hideEmpty: true }) {
        nodes { name }
      }
    }
  `,{},void 0,["categories"]);return["All",...a?.categories?.nodes?.map(a=>a.name)||[]]},r=async()=>{let a=await c(`
    query GetBlogTags {
      tags(first: 15, where: { hideEmpty: true, orderby: COUNT, order: DESC }) {
        nodes { name }
      }
    }
  `,{},void 0,["posts"]);return a?.tags?.nodes?.map(a=>a.name)||[]},s=async()=>{let a=await c(`
    query GetAllProjects {
      projects(first: 100, where: { orderby: { field: DATE, order: DESC } }) {
        nodes {
          id
          title
          slug
          excerpt
          featuredImage { node { sourceUrl } }
          categories { nodes { name, slug } }
          tags { nodes { name } }
          projectFields { location, completionYear, area }
        }
      }
    }
  `,{},void 0,["projects"]);return(a?.projects?.nodes||[]).map(a=>{let b=a.projectFields||{},c=a.categories?.nodes?.[0],d=a.excerpt?a.excerpt.replace(/<[^>]+>/g,"").trim():"";return{id:a.id,title:a.title||"",slug:a.slug||"",image:a.featuredImage?.node?.sourceUrl||"https://via.placeholder.com/800x600",category:c?.name||"Dự án",categorySlug:c?.slug||"other",desc:d,location:b.location||"Việt Nam",year:b.completionYear||"2024",area:b.area||"---",tags:a.tags?.nodes?.map(a=>a.name)||[],architect:"",client:"",challenge:"",solution:"",materials:[],gallery:[],subtitle:""}})},t=async a=>{let b=await c(`
    query GetProjectBySlug($slug: String!) {
      projects(first: 1, where: { name: $slug }) {
        nodes {
          id
          title
          slug
          excerpt
          featuredImage { node { sourceUrl } }
          categories { nodes { name, slug } }
          tags { nodes { name } }
          projectFields {
             location, completionYear, area, architect, client, challenge, solution, materials
             albumImg { nodes { sourceUrl } }
          }
        }
      }
    }
  `,{variables:{slug:a}},void 0,["projects",`project-${a}`]),d=b?.projects?.nodes?.[0];return d?(a=>{if(!a)return{};let b=a.projectFields||{},c=a.categories?.nodes?.[0],d=b.albumImg?.nodes?b.albumImg.nodes.map(a=>a.sourceUrl):[];0===d.length&&a.featuredImage&&d.push(a.featuredImage.node.sourceUrl);let e=b.materials?b.materials.split(/\r?\n|,/).map(a=>a.trim()).filter(Boolean):["Đang cập nhật"],f=a.excerpt?a.excerpt.replace(/<[^>]+>/g,"").trim():"";return{id:a.id,title:a.title||"",slug:a.slug||"",image:a.featuredImage?.node?.sourceUrl||"",category:c?.name||"Dự án",categorySlug:c?.slug||"other",subtitle:c?.name||"Chi tiết dự án",location:b.location||"Việt Nam",year:b.completionYear||"2024",area:b.area||"---",desc:f,architect:b.architect||"Đại Nam Wall Team",client:b.client||"Khách hàng",challenge:b.challenge||"Đang cập nhật nội dung...",solution:b.solution||"Đang cập nhật nội dung...",materials:e,gallery:d,tags:a.tags?.nodes?.map(a=>a.name)||[]}})(d):null},u=async()=>{var a,b,f,g;let h,i=await c(`
    ${d}
    query GetHomePageData {
      page(id: "/", idType: URI) {
        homeSettings {
          heroSlides {
            subtitle, title, description, ctaLink, ctaText
            image { node { sourceUrl } }
            hotspots { x, y, name, price, position, link, isNofollow }
          }
          categoryHeadingNormal
          categoryHeadingHighlight
          categorySubheading
          catalogueText
          enableCatNofollow
          signatureHeadingNormal
          signatureHeadingHighlight
          signatureDesc
          signatureTabs {
            tabName
            products {
              nodes {
                ... on Product { ...ProductFields }
              }
            }
          }
          shopLookHeading
          shopLookSubheading
          shopLookImage {
             node { sourceUrl }
          }
          shopLookItems {
            x, y
            products {
                nodes {             
                ... on Product { ...ProductFields }
              }
            }
          }
          accessoryHighlights {
             title, subtitle, link, image { node { sourceUrl } }
          }
          accViewAll {
             viewAllText, viewAllSub, viewAllLink
          }
          headNormal
          headHighlight
          phuKienSub
          accProdHeading
          accessoryProducts {
            nodes {
              ... on Product { ...ProductFields }
            }
          }
          qualityHeading
          qualitySubheading
          qualityLarge {
            title, description, icon { node { sourceUrl } }, image { node { sourceUrl } }, tags { text }
          }
          qualitySmall {
            title, description, icon { node { sourceUrl } }
          }
        }
      }
      posts(first: 3, where: { orderby: { field: DATE, order: DESC } }) {
        nodes {
          id, title, slug, date, excerpt
          featuredImage { node { sourceUrl } }
          categories { nodes { name, slug } }
          author { node { name, avatar { url } } }
        }
      }
    }
  `,{},void 0,["page-home","products","posts","categories"]),j=i?.page?.homeSettings,n=j||{},o=i?.posts?.nodes||[],p=a=>a?.node?.sourceUrl||"",q=n.accessoryProducts?.nodes?n.accessoryProducts.nodes:n.accessoryProducts;return{heroSlides:j?j?.heroSlides?j.heroSlides.map((a,b)=>({id:b+1,subtitle:a.subtitle||"",title:a.title||"",description:a.description||"",image:a.image?.node?.sourceUrl??"",ctaLink:a.ctaLink||"/shop",ctaText:a.ctaText||"Khám Phá Ngay",productLink:a.productLink||[],hotspots:a.hotspots?a.hotspots.map(a=>({x:a.x||"50%",y:a.y||"50%",name:a.name||"",price:a.price||"",position:a.position||"left",link:a.link||"",nofollow:a.isNofollow||!1})):[]})):[]:[],categoryHeadingNormal:n.categoryHeadingNormal||"Danh Mục",categoryHeadingHighlight:n.categoryHeadingHighlight||"Sản Phẩm",categorySubheading:n.categorySubheading||"",catalogueText:n.catalogueText||"Catalogue 2024",enableCategoryNofollow:n.enableCatNofollow||!1,signatureHeadingNormal:n.signatureHeadingNormal||"Signature",signatureHeadingHighlight:n.signatureHeadingHighlight||"Collection",signatureDesc:n.signatureDesc||"",signatureTabs:(a=n.signatureTabs)?a.map((a,b)=>({id:b,name:a.tabName||`Tab ${b+1}`,products:k(a.products?.nodes||[])})):[],shopLookHeading:n.shopLookHeading||"Shop The Look",shopLookSubheading:n.shopLookSubheading||"",shopLookImage:l(n.shopLookImage),shopLookItems:(b=n.shopLookItems)?b.reduce((a,b,c)=>{let d=b.products?.nodes?.[0];if(!d)return a;let f=e(d);return f&&f.id&&a.push({id:c,x:parseFloat(b.x)||50,y:parseFloat(b.y)||50,product:f}),a},[]):[],headNormal:n.headNormal||"Chi Tiết.",headHighlight:n.headHighlight||"Định Hình Đẳng Cấp.",phuKienSub:n.phuKienSub||" Hệ thống phụ kiện nẹp, phào chỉ và keo dán chuyên dụng được thiết kế đồng bộ để tạo nên sự hoàn hảo cho từng góc cạnh.",accHighlights:(f=n.accessoryHighlights)?f.map((a,b)=>({id:b,title:a.title||"",subtitle:a.subtitle||"",image:l(a.image),link:a.link||"/shop"})):[],accViewAll:{text:n.accViewAll?.viewAllText||"Xem Tất Cả Phụ Kiện",sub:n.accViewAll?.viewAllSub||"Khám phá thêm các vật tư phụ trợ",link:n.accViewAll?.viewAllLink||"/shop"},accProdHeading:n.accProdHeading||"SẢN PHẨM PHỔ BIẾN",accProducts:k(q||[]),qualityHeading:n.qualityHeading||"Tiêu Chuẩn Đại Nam Wall",qualitySubheading:n.qualitySubheading||"",qualityLarge:(h=n.qualityLarge,{title:h?.title||"Cấu Trúc 5 Lớp Siêu Bền",description:h?.description||"Công nghệ ép nhiệt Nano tiên tiến...",icon:p(h?.icon),image:p(h?.image),tags:h?.tags?h.tags.map(a=>({text:a.text})):[]}),qualitySmall:(g=n.qualitySmall)?g.map(a=>({title:a.title||"",description:a.description||"",icon:p(a.icon)})):[],blogPosts:m(o)}},v=async()=>{var a;let b=await c(`
    query GetApplicationOptions {
      applicationOptions {
        appData {
          heroTitle, heroDesc
          spaces {
            name, subtitle, description, image { node { sourceUrl } }
            hotspots { xPos, yPos, label, desc, iconType }
            stats { statLabel, statValue }
          }
          renovationHeading, renovationDesc
          beforeImage { node { sourceUrl } }
          afterImage { node { sourceUrl } }
          renovationFeatures { iconType, title, desc }
          commHeading, commDesc, commLinkText, commLinkUrl 
          commItems { title, desc, image { node { sourceUrl } } }
          ctaHeading, ctaDesc, ctaBtnPrimary, ctaBtnSecondary
        }
      }
    }
  `,{},void 0,["page-applications","options"]),d=b?.applicationOptions?.appData||{},e=(d.spaces||[]).map((a,b)=>{var c,d;return{id:`space-${b}`,name:a.name||"",title:a.subtitle||"",description:a.description||"",image:a.image?.node?.sourceUrl||"",hotspots:(c=a.hotspots)?c.map(a=>({x:a.xPos||50,y:a.yPos||50,label:a.label||"",description:a.desc||"",iconType:a.iconType||"default"})):[],stats:(d=a.stats)?d.map(a=>({label:a.statLabel||"",value:a.statValue||""})):[]}});return{heroTitle:d.heroTitle||"Nghệ Thuật Biến Hóa Không Gian",heroDesc:d.heroDesc||"",spaces:e,renovationHeading:d.renovationHeading||"Cải Tạo Thần Tốc",renovationDesc:d.renovationDesc||"Chứng kiến sự lột xác ngoạn mục...",beforeImage:d.beforeImage?.node?.sourceUrl||"",afterImage:d.afterImage?.node?.sourceUrl||"",renovationFeatures:(a=d.renovationFeatures)?a.map(a=>({icon:a.iconType||"star",title:a.title||"",desc:a.desc||""})):[],commHeading:d.commHeading||"Không Gian Thương Mại",commDesc:d.commDesc||"",commLinkText:d.commLinkText||"Xem dự án thực tế",commLinkUrl:d.commLinkUrl||"/du-an",commItems:d.commItems?.map(a=>({title:a.title||"",desc:a.desc||"",image:a.image?.node?.sourceUrl||""}))||[],ctaHeading:d.ctaHeading||"Bạn Đã Có Ý Tưởng?",ctaDesc:d.ctaDesc||"",ctaBtnPrimary:d.ctaBtnPrimary||"Đăng Ký Tư Vấn",ctaBtnSecondary:d.ctaBtnSecondary||"Xem Catalog"}},w=a=>{if(!a)return null;let b=a.price?parseFloat(a.price.replace(/[^0-9.]/g,"")):0,c=b>0?new Intl.NumberFormat("vi-VN",{style:"currency",currency:"VND"}).format(b):"Liên hệ";return{name:a.name||"",price:c,unit:"",link:`/product/${a.slug}`,image:a.image?.sourceUrl||"https://via.placeholder.com/300"}},x=async()=>{let a=await c(`
    query GetPricingOptions {
      pricingOptions {
        pricingData {
          heroTitle, heroDesc
          calculatorProduct {
            nodes {
              ... on Product {
                id, name, slug, sku, image { sourceUrl }
                ... on SimpleProduct { price(format: RAW) }
                ... on VariableProduct { price(format: RAW) }
                productSpecifications { length, width, thickness }
              }
            }
          }
          basePriceTurnkey, pkgHeading, pkgDesc
          turnkeyPackages { name, price, unit, description, isPopular, styleType, features { text } }
          stepsHeading, stepsDesc
          constructionSteps { stepNumber, title, desc, icon }
          commitments { icon, title, desc }
          materialsHeading, materialsDesc
          materialProducts {
            nodes {
              ... on Product {
                id, name, slug, image { sourceUrl }
                ... on SimpleProduct { price(format: RAW) }
                ... on VariableProduct { price(format: RAW) }
              }
            }
          }
          accHeading, accDesc
          accessoryItems {
            nodes {
              ... on Product {
                id, name, slug, image { sourceUrl }
                ... on SimpleProduct { price(format: RAW) }
                ... on VariableProduct { price(format: RAW) }
              }
            }
          }
          faqs { question, answer }
          ctaHeading, ctaDesc
        }
      }
    }
  `,{},void 0,["page-pricing","products","options"]),b=a?.pricingOptions?.pricingData||{},d=b.calculatorProduct?.nodes?.[0]||null;return{heroTitle:b.heroTitle||"Bảng Giá Niêm Yết 2024",heroDesc:b.heroDesc||"Công cụ tính toán giúp bạn hình dung chi phí sơ bộ...",calculatorProduct:(a=>{if(!a)return null;let b=a.price?parseFloat(a.price.replace(/[^0-9.]/g,"")):0;return{id:a.id,databaseId:0,slug:a.slug,name:a.name,image:{sourceUrl:a.image?.sourceUrl||"",altText:a.name},price:{amount:b,formatted:""},dimensions:{length:Number(a.productSpecifications?.length)||0,width:Number(a.productSpecifications?.width)||0,thickness:Number(a.productSpecifications?.thickness)||0,area:0},brand:"",origin:"",surface:"",warranty:"",description:"",shortDescription:"",galleryImages:[],stockStatus:"IN_STOCK",sku:a.sku||"",categories:[]}})(d),basePriceTurnkey:Number(b.basePriceTurnkey)||55e4,pkgHeading:b.pkgHeading||"1. Báo Giá Thi Công Trọn Gói",pkgDesc:b.pkgDesc||"Giải pháp tối ưu nhất cho khách hàng bận rộn...",turnkeyPackages:b.turnkeyPackages?.map((a,b)=>{let c;return{id:b,name:a.name||"",price:a.price||"",unit:a.unit||"đ/m2",description:a.description||"",isPopular:a.isPopular||!1,styleType:a.styleType||"standard",features:(c=a.features,c?.map(a=>a.text||"")||[])}})||[],stepsHeading:b.stepsHeading||"Quy Trình Thi Công",stepsDesc:b.stepsDesc||"Sự chuyên nghiệp tạo nên chất lượng...",constructionSteps:b.constructionSteps?.map(a=>({step:a.stepNumber||`0${a+1}`,title:a.title||"",desc:a.desc||"",icon:a.icon||"default"}))||[],commitments:b.commitments?.map(a=>({icon:a.icon||"thumbsup",title:a.title||"",desc:a.desc||""}))||[],materialsHeading:b.materialsHeading||"2. Báo Giá Vật Tư Lẻ",materialsDesc:b.materialsDesc||"Mua vật liệu chính hãng giá tại kho...",materialItems:b.materialProducts?.nodes?.map(w)||[],accHeading:b.accHeading||"3. Phụ Kiện Thi Công",accDesc:b.accDesc||"Các vật tư phụ cần thiết...",accessoryItems:b.accessoryItems?.nodes?.map(w)||[],faqs:b.faqs?.map(a=>({question:a.question||"",answer:a.answer||""}))||[],ctaHeading:b.ctaHeading||"Bạn Vẫn Còn Phân Vân?",ctaDesc:b.ctaDesc||"Đừng lo lắng. Hãy để chuyên gia kỹ thuật hỗ trợ."}},y=async()=>{let a=await c(`
    query GetContactOptions {
      contactOptions {
        contactData {
          heroTitle, heroDesc, heroImage { node { sourceUrl } }
          address, hotline, email, workingHours, zaloUrl, facebookUrl
          mapEmbedUrl
          formHeading, formDesc, namePlaceholder, phonePlaceholder, emailPlaceholder
          messagePlaceholder, btnText, successTitle, successMessage
          topics { value, label }
          faqsContact { question, answer }
        }
      }
    }
  `,{},void 0,["page-contact","options"]),b=a?.contactOptions?.contactData||{};return{heroTitle:b.heroTitle||"Liên Hệ Với Chúng Tôi",heroDesc:b.heroDesc||"Chúng tôi luôn sẵn sàng lắng nghe và giải đáp mọi thắc mắc của bạn.",heroImage:b.heroImage?.node?.sourceUrl||"https://via.placeholder.com/1920x600",info:{address:b.address||"Đang cập nhật địa chỉ...",hotline:b.hotline||"0912.345.678",email:b.email||"info@domain.com",workingHours:b.workingHours||"Thứ 2 - Thứ 7: 8:00 - 17:30",zaloUrl:b.zaloUrl||"#",facebookUrl:b.facebookUrl||"#"},mapUrl:b.mapEmbedUrl||"",form:{heading:b.formHeading||"Gửi Tin Nhắn",desc:b.formDesc||"Vui lòng điền thông tin bên dưới, chúng tôi sẽ liên hệ lại ngay."},formConfig:{heading:b.formHeading||"Gửi Tin Nhắn",desc:b.formDesc||"Vui lòng điền thông tin bên dưới, chúng tôi sẽ liên hệ lại ngay.",namePlaceholder:b.namePlaceholder||"Nguyễn Văn A",phonePlaceholder:b.phonePlaceholder||"0912 xxx xxx",emailPlaceholder:b.emailPlaceholder||"example@gmail.com",messagePlaceholder:b.messagePlaceholder||"Nội dung cần tư vấn...",btnText:b.btnText||"Gửi Yêu Cầu",successTitle:b.successTitle||"Gửi thành công!",successMessage:b.successMessage||"Cảm ơn bạn đã liên hệ. Chúng tôi sẽ phản hồi sớm nhất.",topics:b.topics?.map(a=>({value:a.value||"general",label:a.label||"Tư vấn chung"}))||[{value:"advice",label:"Tư vấn sản phẩm"}]},faqsContact:b.faqsContact?.map(a=>({question:a.question||"",answer:a.answer||""}))||[]}},z=async()=>{let a=await c(`
    query GetHeaderOptions {
      headerFooterOptions {
        headerData {
          logo { node { sourceUrl } }
          topBarText, hotline
          navItems { title, link }
          megaMenu {
            col1Title
            col1Items { categoryLink { nodes { name, slug } }, customTitle, desc, icon, color }
            col2Title
            col2Items { categoryLink { nodes { name, slug } }, customTitle, desc, icon, color }
            quickLinks { title, link }
            banner { image { node { sourceUrl } }, badgeText, title, desc, linkText, linkUrl }
          }
        }
      }
    }
  `,{},void 0,["header","global-options"]),b=a?.headerFooterOptions?.headerData||{},d=b.megaMenu||{},e=a=>a?a.map(a=>{let b=a.categoryLink?.nodes?.[0];return{title:a.customTitle||b?.name||"Đang cập nhật...",slug:b?.slug||"",desc:a.desc||"",icon:a.icon||"Box",color:a.color||"text-slate-600 bg-slate-50"}}):[];return{logo:b.logo?.node?.sourceUrl||"/images/default-logo.png",topBarText:b.topBarText||"",hotline:b.hotline||"0909.xxx.xxx",navItems:b.navItems?.map(a=>({title:a.title||"",link:a.link||"/"}))||[],megaMenu:{col1:{title:d.col1Title||"Vật Liệu Chính",items:e(d.col1Items)},col2:{title:d.col2Title||"Phụ Kiện & Khác",items:e(d.col2Items)},quickLinks:d.quickLinks?.map(a=>({title:a.title||"",link:a.link||"#"}))||[],banner:{image:d.banner?.image?.node?.sourceUrl||"https://images.unsplash.com/photo-1620626012053-93f56b5463f0?q=80&w=800&auto=format&fit=crop",badge:d.banner?.badgeText||"New Collection",title:d.banner?.title||"Vẻ Đẹp Vượt Thời Gian",desc:d.banner?.desc||"Khám phá bộ sưu tập mới nhất.",linkText:d.banner?.linkText||"Xem Ngay",linkUrl:d.banner?.linkUrl||"/shop"}}}},A=async()=>{let a=await c(`
    query GetFooterOptions {
      headerFooterOptions {
        footerSettings {
          footerData {
            trustBadges { icon, title, desc }
            companyInfo { logoText, desc, address, phone, email }
            shopCategories { title, links { title, url, badge, badgeColor } }
            customerService { title, links { title, url } }
            socialLinks { facebook, instagram, youtube }
            bottomBar { copyright, links { title, url } }
          }
        }
      }
    }
  `,{},void 0,["footer","global-options"]),b=a?.headerFooterOptions?.footerSettings?.footerData||{};return{trustBadges:b.trustBadges||[{icon:"Truck",title:"Giao hàng toàn quốc",desc:"Hỗ trợ vận chuyển tận nơi"},{icon:"ShieldCheck",title:"Bảo hành 15 năm",desc:"Cam kết chất lượng vật liệu"},{icon:"CreditCard",title:"Thanh toán linh hoạt",desc:"Đa dạng phương thức"},{icon:"Headphones",title:"Hỗ trợ 24/7",desc:"Tư vấn kỹ thuật thi công"}],companyInfo:{logoText:b.companyInfo?.logoText||"ĐẠI NAM WALL",desc:b.companyInfo?.desc||"Tổng kho phân phối vật liệu ốp tường cao cấp...",address:b.companyInfo?.address||"123 Đ. Nguyễn Văn Linh, Q. Long Biên, Hà Nội",phone:b.companyInfo?.phone||"0912.345.678",email:b.companyInfo?.email||"sale@dainamwall.com"},shopCategories:{title:b.shopCategories?.title||"Danh mục mua sắm",links:b.shopCategories?.links||[]},customerService:{title:b.customerService?.title||"Hỗ trợ dịch vụ",links:b.customerService?.links||[]},socialLinks:{facebook:b.socialLinks?.facebook||"#",instagram:b.socialLinks?.instagram||"#",youtube:b.socialLinks?.youtube||"#"},bottomBar:{copyright:b.bottomBar?.copyright||"Công ty TNHH Đại Nam Wall.",links:b.bottomBar?.links||[]}}};a.s(["getAllProjects",0,s,"getApplicationsPageData",0,v,"getBlogCategoriesList",0,q,"getBlogTagsList",0,r,"getCategories",0,j,"getContactPageData",0,y,"getFooterData",0,A,"getHeaderData",0,z,"getHomeData",0,u,"getPaginatedPosts",0,p,"getPostBySlug",0,n,"getPricingPageData",0,x,"getProductBySlug",0,h,"getProducts",0,f,"getProjectBySlug",0,t,"getRelatedPosts",0,o,"getShopSettings",0,g])}];

//# sourceMappingURL=src_services_wpService_ts_982deead._.js.map