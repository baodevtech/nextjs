module.exports=[84595,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_du-an_%5Bid%5D_page_actions_2a6d203f.js.map