var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/revalidate/route.js")
R.c("server/chunks/[externals]__94b6c289._.js")
R.c("server/chunks/[root-of-the-server]__b30e0925._.js")
R.c("server/chunks/_next-internal_server_app_api_revalidate_route_actions_415b884f.js")
R.m(94579)
module.exports=R.m(94579).exports
