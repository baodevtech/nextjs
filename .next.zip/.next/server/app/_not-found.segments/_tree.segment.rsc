:HL["/_next/static/chunks/c4ce374513763684.css","style"]
:HL["/_next/static/chunks/337c32c09293bd43.css","style"]
0:{"buildId":"8P5XapvTCSGCdenDtMCAT","tree":{"name":"","paramType":null,"paramKey":"","hasRuntimePrefetch":false,"slots":{"children":{"name":"/_not-found","paramType":null,"paramKey":"/_not-found","hasRuntimePrefetch":false,"slots":{"children":{"name":"__PAGE__","paramType":null,"paramKey":"__PAGE__","hasRuntimePrefetch":false,"slots":null,"isRootLayout":false}},"isRootLayout":false}},"isRootLayout":true},"staleTime":300}
