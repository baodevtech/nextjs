module.exports=[16407,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_du-an_page_actions_75351de6.js.map