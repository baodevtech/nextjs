1:"$Sreact.fragment"
2:I[39756,["/_next/static/chunks/d2be314c3ece3fbe.js","/_next/static/chunks/10bf1ca2fbe39d33.js"],"default"]
3:I[37457,["/_next/static/chunks/d2be314c3ece3fbe.js","/_next/static/chunks/10bf1ca2fbe39d33.js"],"default"]
0:{"buildId":"LWdQuxKhgtmwC8Wdkzw44","rsc":["$","$1","c",{"children":[null,["$","$L2",null,{"parallelRouterKey":"children","template":["$","$L3",null,{}]}]]}],"loading":null,"isPartial":false}
