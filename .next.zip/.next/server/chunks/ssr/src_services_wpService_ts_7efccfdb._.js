module.exports=[97381,a=>{"use strict";let b=process.env.NEXT_PUBLIC_WORDPRESS_API_URL||"https://portal.khopanel.com/graphql";async function c(a,{variables:d}={},e){try{let c=await fetch(b,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({query:a,variables:d}),next:{revalidate:e??3600}}),f=await c.json();if(f.errors)return null;return f.data}catch(a){return null}}let d=`
  fragment ProductFields on Product {
    id
    databaseId
    slug
    name
    sku
    shortDescription
    description
    ... on SimpleProduct {
      price(format: RAW)
      regularPrice(format: RAW)
      stockStatus
    }
    ... on VariableProduct {
      price(format: RAW)
      regularPrice(format: RAW)
      stockStatus
    }
    image {
      sourceUrl
      altText
    }
    galleryImages {
      nodes {
        sourceUrl
        altText
      }
    }
    productCategories {
      nodes {
        slug
        name
      }
    }
    productBrands {
      nodes {
        name
        slug
      }
    }
    productSpecifications {
      length
      width
      thickness
      area
      origin
      surface
      warranty
    }
  }
`,e=a=>{if(!a)return{};let b=a.price?parseFloat(a.price.replace(/[^0-9.]/g,"")):0,c=a.productBrands?.nodes&&a.productBrands.nodes.length>0?a.productBrands.nodes[0].name:"Đại Nam Wall";return{id:a.id,databaseId:a.databaseId,slug:a.slug,name:a.name,brand:c,origin:a.productSpecifications?.origin||"",surface:a.productSpecifications?.surface||"",warranty:a.productSpecifications?.warranty||"",description:a.description||"",shortDescription:a.shortDescription||"",image:{sourceUrl:a.image?.sourceUrl||"https://via.placeholder.com/600x600?text=No+Image",altText:a.image?.altText||a.name},galleryImages:a.galleryImages?.nodes?.map(b=>({sourceUrl:b.sourceUrl,altText:b.altText||a.name}))||[],price:{amount:b,formatted:new Intl.NumberFormat("vi-VN",{style:"currency",currency:"VND"}).format(b)},stockStatus:"IN_STOCK"===a.stockStatus?"IN_STOCK":"OUT_OF_STOCK",sku:a.sku||"",categories:a.productCategories?.nodes?.map(a=>a.slug)||[],dimensions:{length:Number(a.productSpecifications?.length)||0,width:Number(a.productSpecifications?.width)||0,thickness:Number(a.productSpecifications?.thickness)||0,area:Number(a.productSpecifications?.area)||0}}},f=async()=>{let a=await c(`
    ${d}
    query GetProducts {
      products(first: 20, where: { orderby: { field: DATE, order: DESC } }) {
        nodes {
          ...ProductFields
        }
      }
    }
  `);return a&&a.products?a.products.nodes.map(e):[]},g=async()=>{let a=await c(`
    query GetShopSettings {
      options {
        shopSettings {
          shopDescription
          benefitWarranty {
            heading
            subHeading
            icon { node { sourceUrl } }
          }
          benefitShipping {
            heading
            subHeading
            icon { node { sourceUrl } }
          }
          benefitVariety {
            heading
            subHeading
            icon { node { sourceUrl } }
          }
        }
      }
    }
  `),b=a?.options?.shopSettings;return b?{description:b.shopDescription||"",benefits:{warranty:{heading:b.benefitWarranty?.heading||"",subHeading:b.benefitWarranty?.subHeading||"",icon:b.benefitWarranty?.icon?.node?.sourceUrl||""},shipping:{heading:b.benefitShipping?.heading||"",subHeading:b.benefitShipping?.subHeading||"",icon:b.benefitShipping?.icon?.node?.sourceUrl||""},variety:{heading:b.benefitVariety?.heading||"",subHeading:b.benefitVariety?.subHeading||"",icon:b.benefitVariety?.icon?.node?.sourceUrl||""}}}:null},h=a=>({id:a.id,name:a.name,slug:a.slug,count:a.count||0,image:a.image?.sourceUrl||"https://via.placeholder.com/400x400?text=Category",description:a.description,headerImage:a.categoryExtras?.headerImage?.node?.sourceUrl||a.image?.sourceUrl||"",bottomContent:a.categoryExtras?.bottomContent||"",trendHeader:a.categoryExtras?.trendHeader||"",trendContent:a.categoryExtras?.trendContent||"",warrantyMonths:a.categoryExtras?.warrantyMonths||0}),i=async()=>{let a=await c(`
    query GetCategories {
      productCategories(first: 20, where: { hideEmpty: true, parent: 0 }) {
        nodes {
          id
          name
          slug
          count
          description
          image {
            sourceUrl
          }
          categoryExtras {
            headerImage { node { sourceUrl } }
            bottomContent
            trendHeader
            trendContent
            warrantyMonths
          }
        }
      }
    }
  `);return a&&a.productCategories?a.productCategories.nodes.map(h):[]},j=async a=>{let c=b.replace("/graphql","/wp-json/dainam/v1/contact");try{let b=await fetch(c,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(a)}),d=await b.json();if(!b.ok)throw Error(d.message||"Lỗi khi gửi form");return d}catch(a){return null}},k=`
mutation AddToCart($productId: Int!, $quantity: Int!) {
  addToCart(input: { productId: $productId, quantity: $quantity }) {
    cart {
      contents {
        nodes {
          key
          quantity
          product {
            node {
              name
              databaseId
            }
          }
        }
      }
    }
  }
}
`,l=`
mutation Checkout($input: CheckoutInput!) {
  checkout(input: $input) {
    result
    redirect
    order {
      databaseId
      orderNumber
      status
      total
    }
  }
}
`,m=async(a,c={})=>{let d=await fetch(b,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({query:a,variables:c}),credentials:"include",cache:"no-store"});return d.headers.get("woocommerce-session")||d.headers.get("x-woocommerce-session"),d.json()},n=async(a,b)=>{try{let c=a.name.trim(),d=c.lastIndexOf(" "),e=c,f=".";for(let a of(d>0&&(e=c.substring(0,d),f=c.substring(d+1)),b)){let b=Number(a.databaseId);if(!b||isNaN(b))continue;let c=await m(k,{productId:b,quantity:a.quantity});if(c.errors)return{success:!1,message:c.errors[0].message}}let g={clientMutationId:`order_${Date.now()}`,paymentMethod:a.paymentMethod||"cod",isPaid:!1,billing:{firstName:e,lastName:f,address1:a.address,city:"Hồ Chí Minh",country:"VN",phone:a.phone,email:a.email||"no-email@example.com"},shipping:{firstName:e,lastName:f,address1:a.address,city:"Hồ Chí Minh",country:"VN"},customerNote:a.note},h=await m(l,{input:g});if(h.errors)return{success:!1,message:h.errors[0].message};return{success:!0,order:h.data?.checkout?.order}}catch(a){return{success:!1,message:"Lỗi hệ thống: "+(a instanceof Error?a.message:String(a))}}};a.s(["createOrder",0,n,"getCategories",0,i,"getProducts",0,f,"getShopSettings",0,g,"submitContactForm",0,j])}];

//# sourceMappingURL=src_services_wpService_ts_7efccfdb._.js.map